<FORM method="POST" action="/customers/create"> <?php echo csrf_field(); ?>
     Enter your first name:<input type="text" name="firstname"><br>
     Enter your surname:<input type="text" name="surname"><br>
     <input type="submit">
</FORM><?php /**PATH C:\larvel\customerApp\resources\views/customers/new.blade.php ENDPATH**/ ?>