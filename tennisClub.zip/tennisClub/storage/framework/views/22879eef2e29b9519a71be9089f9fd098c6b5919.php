<!-- Surface Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('surface', 'Surface:'); ?>

    <?php echo Form::text('surface', null, ['class' => 'form-control']); ?>

</div>

<!-- Floodlights Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('floodlights', 'Floodlights:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('floodlights', false); ?>

        <?php echo Form::checkbox('floodlights', 1, null); ?> $VALUE$
    </label>
</div>

<!-- Indoor Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('indoor', 'Indoor:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('indoor', false); ?>

        <?php echo Form::checkbox('indoor', 1, null); ?> $VALUE$
    </label>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('courts.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\larvel\tennisClub\resources\views/courts/fields.blade.php ENDPATH**/ ?>